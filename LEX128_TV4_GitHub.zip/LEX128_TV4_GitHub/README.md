# LEX-128 — TV4: Kiểm tra đầu vào và khởi tạo IV

Repository này hiện thực phần TV4 theo hai tài liệu báo cáo được cung cấp, gồm:

- Kiểm tra và chuẩn hóa khóa, IV, dữ liệu (`validation.py`).
- Ngữ cảnh khóa và trạng thái luồng (`context.py`).
- Mở rộng khóa và mã hóa một khối AES-128 (`aes.py`).
- Đảo thứ tự byte theo từng từ 32 bit của IV và tính trạng thái ban đầu `S0` (`iv_setup.py`).
- Bộ kiểm thử đơn vị và ví dụ chạy thử.

Công thức khởi tạo được sử dụng:

```text
IV' = swap32(IV)
S0  = AES-128(K, IV')
```

Trong đó `swap32` đảo thứ tự byte riêng trong từng nhóm 4 byte. `compute_s0` sử dụng AES-128 chuẩn: AddRoundKey ban đầu, 9 vòng đầy đủ và vòng cuối không có MixColumns.

## Cấu trúc thư mục

```text
src/lex/lex/
├── aes.py          # Key schedule và mã hóa khối AES-128
├── context.py      # KeyContext và StreamContext
├── iv_setup.py     # make_key_context, swap32_words, compute_s0
└── validation.py   # validate_key, validate_iv, validate_data

tests/unit/
├── test_context.py
├── test_iv_setup.py
└── test_validation.py

examples/tv4_demo.py
run_tests.py
pyproject.toml
```

## Yêu cầu

- Python 3.10 trở lên.
- Không cần thư viện bên thứ ba để chạy mã và test.

## Chạy kiểm thử

Đứng tại thư mục gốc của repository và chạy:

```bash
python run_tests.py
```

Bộ test hiện có kiểm tra kiểm tra đầu vào, ngữ cảnh, đổi byte IV và các vector AES-128 đã biết, cùng ví dụ `S0` có trong báo cáo TV4.

## Chạy ví dụ

```bash
python examples/tv4_demo.py
```

Với `Key = 00...00` và `IV = 00112233445566778899aabbccddeeff`, kết quả cần có:

```text
IV' : 3322110077665544bbaa9988ffeeddcc
S0  : 1c74a257b03aa9b2e92434cf1f99f209
```

## API cơ bản

```python
from lex.lex import compute_s0, make_key_context, validate_iv, validate_key

key = validate_key(bytes(16))
iv = validate_iv(bytes(16))
key_context = make_key_context(key)  # Mở rộng khóa một lần thành K0..K10
s0 = compute_s0(key_context, iv)
```

Có thể cài package ở chế độ editable nếu muốn import từ môi trường Python khác:

```bash
python -m pip install -e .
```

## Đưa mã nguồn lên GitHub

1. Tạo một repository trống trên GitHub.
2. Giải nén thư mục này, mở terminal tại thư mục gốc rồi chạy:

```bash
git init
git add .
git commit -m "Add LEX-128 TV4 implementation"
git branch -M main
git remote add origin https://github.com/<tai-khoan>/<ten-repository>.git
git push -u origin main
```

Thay URL mẫu bằng URL repository của bạn.

## Phạm vi và lưu ý

Repository này chỉ hiện thực phần TV4 (kiểm tra đầu vào, ngữ cảnh và khởi tạo IV). Nó **không** hiện thực động cơ vòng LEX (TV3), bộ đệm keystream (TV5) hoặc mã tấn công Dunkelman–Keller. Hai PDF cung cấp mô tả và ví dụ nhưng không chứa toàn bộ source tree hay đầy đủ vector tham chiếu, vì vậy không thể tái tạo độc lập tuyên bố 88 test và 96/96 vector KAT của toàn dự án. Bộ test đi kèm kiểm tra phần mã được cung cấp ở đây.

Mã AES viết bằng Python nhằm mục đích học tập, không được thiết kế để chống tấn công kênh kề. LEX có các điểm yếu mật mã đã được phân tích trong chính báo cáo; không sử dụng mã này để bảo vệ dữ liệu thực tế.

## Cơ sở xây dựng

Mã nguồn được xây dựng từ hai tài liệu TV4 do người dùng cung cấp, tập trung vào quy tắc kiểm tra dữ liệu, hợp đồng của `KeyContext`/`StreamContext`, thứ tự byte IV và các giá trị ví dụ. Trước khi nộp, hãy đối chiếu thêm với yêu cầu cụ thể của môn học hoặc repository chung của nhóm.
