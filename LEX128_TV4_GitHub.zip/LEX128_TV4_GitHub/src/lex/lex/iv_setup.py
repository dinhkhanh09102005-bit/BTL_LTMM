"""TV4 key-context creation and initialization-vector setup."""

from __future__ import annotations

from .aes import encrypt_block, expand_key
from .context import KeyContext
from .validation import validate_data, validate_iv, validate_key

BLOCK_SIZE = 16


def make_key_context(key: object) -> KeyContext:
    """Validate an AES-128 key and expand it once into K0..K10."""
    key_bytes = validate_key(key)
    return KeyContext(round_keys=expand_key(key_bytes))


def swap32_words(block: object) -> bytes:
    """Reverse byte order inside each 32-bit word of a 16-byte block.

    Example: ``00 11 22 33 | 44 55 66 77`` becomes
    ``33 22 11 00 | 77 66 55 44``.
    """
    value = validate_data(block)
    if len(value) != BLOCK_SIZE:
        raise ValueError(f"block must be exactly {BLOCK_SIZE} bytes; got {len(value)}")
    return b"".join(value[offset : offset + 4][::-1] for offset in range(0, BLOCK_SIZE, 4))


def compute_s0(key_ctx: KeyContext, iv: object) -> bytes:
    """Compute S0 = AES-128(K, swap32(IV)) using standard AES-128 rounds."""
    if not isinstance(key_ctx, KeyContext):
        raise TypeError("key_ctx must be a KeyContext")
    iv_bytes = validate_iv(iv)
    swapped_iv = swap32_words(iv_bytes)
    return encrypt_block(swapped_iv, key_ctx.round_keys)
