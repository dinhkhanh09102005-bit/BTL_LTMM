"""Data containers for key-dependent and stream-dependent state."""

from __future__ import annotations

from dataclasses import dataclass

from .validation import validate_data


@dataclass(frozen=True)
class KeyContext:
    """AES-128 expanded key: K0 through K10, 16 bytes per round key.

    ``frozen=True`` prevents replacing the ``round_keys`` attribute. Because
    the list itself is mutable, callers should treat its elements as
    read-only. This matches the module contract described in the TV4 report.
    """

    round_keys: list[bytes]


@dataclass
class StreamContext:
    """State passed between LEX stream-generation cycles (16 bytes)."""

    state: bytes

    def __post_init__(self) -> None:
        value = validate_data(self.state)
        if len(value) != 16:
            raise ValueError(f"stream state must be exactly 16 bytes; got {len(value)}")
        self.state = value
