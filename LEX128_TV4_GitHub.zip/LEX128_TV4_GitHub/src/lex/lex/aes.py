"""Small, dependency-free AES-128 block primitive for TV4.

This module implements standard AES-128 key expansion and block encryption.
It is included so the TV4 IV-setup code and its tests can run without an
external cryptography package. It is educational code, not a hardened,
constant-time cryptographic implementation.
"""

from __future__ import annotations

from collections.abc import Sequence

from .validation import validate_data, validate_key

S_BOX = bytes.fromhex(
    "637c777bf26b6fc53001672bfed7ab76"
    "ca82c97dfa5947f0add4a2af9ca472c0"
    "b7fd9326363ff7cc34a5e5f171d83115"
    "04c723c31896059a071280e2eb27b275"
    "09832c1a1b6e5aa0523bd6b329e32f84"
    "53d100ed20fcb15b6acbbe394a4c58cf"
    "d0efaafb434d338545f9027f503c9fa8"
    "51a3408f929d38f5bcb6da2110fff3d2"
    "cd0c13ec5f974417c4a77e3d645d1973"
    "60814fdc222a908846eeb814de5e0bdb"
    "e0323a0a4906245cc2d3ac629195e479"
    "e7c8376d8dd54ea96c56f4ea657aae08"
    "ba78252e1ca6b4c6e8dd741f4bbd8b8a"
    "703eb5664803f60e613557b986c11d9e"
    "e1f8981169d98e949b1e87e9ce5528df"
    "8ca1890dbfe6426841992d0fb054bb16"
)


def _xtime(value: int) -> int:
    """Multiply a byte by x in GF(2^8), using AES polynomial 0x11B."""
    value <<= 1
    if value & 0x100:
        value ^= 0x11B
    return value & 0xFF


def expand_key(key: object) -> list[bytes]:
    """Expand a 16-byte key into the eleven AES-128 round keys."""
    key_bytes = validate_key(key)
    words = [list(key_bytes[i : i + 4]) for i in range(0, 16, 4)]
    rcon = 1

    for index in range(4, 44):
        temp = words[index - 1].copy()
        if index % 4 == 0:
            temp = temp[1:] + temp[:1]  # RotWord
            temp = [S_BOX[byte] for byte in temp]  # SubWord
            temp[0] ^= rcon
            rcon = _xtime(rcon)
        words.append(
            [words[index - 4][j] ^ temp[j] for j in range(4)]
        )

    return [
        bytes(byte for word in words[start : start + 4] for byte in word)
        for start in range(0, 44, 4)
    ]


def _sub_bytes(state: list[int]) -> list[int]:
    return [S_BOX[byte] for byte in state]


def _shift_rows(state: list[int]) -> list[int]:
    # AES state is represented in column-major byte order: index = 4 * col + row.
    return [
        state[4 * ((column + row) % 4) + row]
        for column in range(4)
        for row in range(4)
    ]


def _mix_columns(state: list[int]) -> list[int]:
    output = state.copy()
    for column in range(4):
        offset = 4 * column
        a0, a1, a2, a3 = state[offset : offset + 4]
        total = a0 ^ a1 ^ a2 ^ a3
        output[offset] = a0 ^ total ^ _xtime(a0 ^ a1)
        output[offset + 1] = a1 ^ total ^ _xtime(a1 ^ a2)
        output[offset + 2] = a2 ^ total ^ _xtime(a2 ^ a3)
        output[offset + 3] = a3 ^ total ^ _xtime(a3 ^ a0)
    return output


def _add_round_key(state: list[int], round_key: bytes) -> list[int]:
    return [byte ^ round_key[index] for index, byte in enumerate(state)]


def encrypt_block(block: object, round_keys: Sequence[bytes]) -> bytes:
    """Encrypt one 16-byte block with pre-expanded AES-128 round keys."""
    value = validate_data(block)
    if len(value) != 16:
        raise ValueError(f"AES block must be exactly 16 bytes; got {len(value)}")
    if len(round_keys) != 11 or any(len(round_key) != 16 for round_key in round_keys):
        raise ValueError("AES-128 requires 11 round keys of exactly 16 bytes each")

    state = _add_round_key(list(value), round_keys[0])
    for round_index in range(1, 10):
        state = _sub_bytes(state)
        state = _shift_rows(state)
        state = _mix_columns(state)
        state = _add_round_key(state, round_keys[round_index])

    # Standard AES final round omits MixColumns.
    state = _sub_bytes(state)
    state = _shift_rows(state)
    state = _add_round_key(state, round_keys[10])
    return bytes(state)


def aes128_encrypt(block: object, key: object) -> bytes:
    """Convenience wrapper that encrypts one block using a 16-byte key."""
    return encrypt_block(block, expand_key(key))
