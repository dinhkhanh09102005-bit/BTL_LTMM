"""Input validation helpers used at the public API boundary."""

from __future__ import annotations

from typing import TypeAlias

BytesLike: TypeAlias = bytes | bytearray | memoryview
KEY_SIZE = 16
IV_SIZE = 16


def _as_bytes(value: object, name: str) -> bytes:
    """Return an independent bytes copy of a bytes-like value.

    Strings and other objects are deliberately rejected instead of being
    silently converted. In particular, ``bytes(16)`` creates 16 zero bytes,
    which could otherwise hide a caller error.
    """
    if not isinstance(value, (bytes, bytearray, memoryview)):
        raise TypeError(
            f"{name} must be bytes, bytearray, or memoryview; "
            f"got {type(value).__name__}"
        )
    return bytes(value)


def validate_key(key: object) -> bytes:
    """Validate and copy a 16-byte AES-128 key."""
    value = _as_bytes(key, "key")
    if len(value) != KEY_SIZE:
        raise ValueError(f"key must be exactly {KEY_SIZE} bytes; got {len(value)}")
    return value


def validate_iv(iv: object) -> bytes:
    """Validate and copy a 16-byte initialization vector."""
    value = _as_bytes(iv, "iv")
    if len(value) != IV_SIZE:
        raise ValueError(f"iv must be exactly {IV_SIZE} bytes; got {len(value)}")
    return value


def validate_data(data: object) -> bytes:
    """Validate and copy arbitrary-length plaintext/ciphertext data."""
    return _as_bytes(data, "data")
