"""TV4: input validation, key context, and IV initialization for LEX-128."""

from .context import KeyContext, StreamContext
from .iv_setup import compute_s0, make_key_context, swap32_words
from .validation import validate_data, validate_iv, validate_key

__all__ = [
    "KeyContext",
    "StreamContext",
    "compute_s0",
    "make_key_context",
    "swap32_words",
    "validate_data",
    "validate_iv",
    "validate_key",
]
