"""Namespace package for the LEX-128 teaching project."""
