"""Demonstrate TV4 initialization with the vector printed in the report."""

from pathlib import Path
import sys

# Make the example runnable directly from a fresh source checkout.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from lex.lex import compute_s0, make_key_context, swap32_words

key = bytes(16)
iv = bytes.fromhex("00112233445566778899aabbccddeeff")
key_context = make_key_context(key)

print(f"Key : {key.hex()}")
print(f"IV  : {iv.hex()}")
print(f"IV' : {swap32_words(iv).hex()}")
print(f"S0  : {compute_s0(key_context, iv).hex()}")
