import unittest

from lex.lex.validation import validate_data, validate_iv, validate_key


class ValidationTests(unittest.TestCase):
    def test_key_accepts_supported_bytes_like_types(self):
        raw = bytes(range(16))
        for value in (raw, bytearray(raw), memoryview(raw)):
            with self.subTest(value_type=type(value).__name__):
                result = validate_key(value)
                self.assertIs(type(result), bytes)
                self.assertEqual(result, raw)

    def test_iv_accepts_supported_bytes_like_types(self):
        raw = bytes(range(16))
        for value in (raw, bytearray(raw), memoryview(raw)):
            with self.subTest(value_type=type(value).__name__):
                self.assertEqual(validate_iv(value), raw)

    def test_wrong_types_are_rejected_before_length_check(self):
        for value in ("0123456789abcdef", 16, [], (), 1.0, None):
            with self.subTest(value=value):
                with self.assertRaises(TypeError):
                    validate_key(value)

    def test_wrong_key_lengths_are_rejected(self):
        for size in (0, 1, 15, 17, 24, 32):
            with self.subTest(size=size):
                with self.assertRaises(ValueError):
                    validate_key(bytes(size))

    def test_wrong_iv_lengths_are_rejected(self):
        for size in (0, 1, 15, 17, 24, 32):
            with self.subTest(size=size):
                with self.assertRaises(ValueError):
                    validate_iv(bytes(size))

    def test_bytearray_input_is_copied(self):
        original = bytearray(range(16))
        result = validate_key(original)
        original[0] = 255
        self.assertEqual(result[0], 0)
        self.assertIs(type(result), bytes)

    def test_data_can_have_any_length(self):
        self.assertEqual(validate_data(b""), b"")
        self.assertEqual(validate_data(bytearray(b"payload")), b"payload")

    def test_data_rejects_strings(self):
        with self.assertRaises(TypeError):
            validate_data("payload")


if __name__ == "__main__":
    unittest.main()
