import unittest
from dataclasses import FrozenInstanceError

from lex.lex.context import KeyContext, StreamContext
from lex.lex.iv_setup import make_key_context


class ContextTests(unittest.TestCase):
    def test_key_context_contains_eleven_round_keys(self):
        context = make_key_context(bytes(16))
        self.assertEqual(len(context.round_keys), 11)
        self.assertTrue(all(len(key) == 16 for key in context.round_keys))
        self.assertEqual(context.round_keys[0], bytes(16))
        self.assertEqual(context.round_keys[1].hex(), "62636363626363636263636362636363")

    def test_key_context_attribute_is_frozen(self):
        context = make_key_context(bytes(16))
        with self.assertRaises(FrozenInstanceError):
            context.round_keys = []

    def test_stream_context_keeps_a_16_byte_state(self):
        state = bytearray(range(16))
        context = StreamContext(state=state)
        state[0] = 255
        self.assertEqual(context.state, bytes(range(16)))
        self.assertIs(type(context.state), bytes)

    def test_stream_context_rejects_invalid_state_length(self):
        with self.assertRaises(ValueError):
            StreamContext(state=b"short")


if __name__ == "__main__":
    unittest.main()
