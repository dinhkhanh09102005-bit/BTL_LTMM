import unittest

from lex.lex.aes import aes128_encrypt
from lex.lex.iv_setup import compute_s0, make_key_context, swap32_words


class IvSetupTests(unittest.TestCase):
    def test_aes_fips_197_known_answer(self):
        key = bytes.fromhex("000102030405060708090a0b0c0d0e0f")
        plaintext = bytes.fromhex("00112233445566778899aabbccddeeff")
        expected = bytes.fromhex("69c4e0d86a7b0430d8cdb78070b4c55a")
        self.assertEqual(aes128_encrypt(plaintext, key), expected)

    def test_zero_key_and_zero_block_aes_vector(self):
        self.assertEqual(
            aes128_encrypt(bytes(16), bytes(16)).hex(),
            "66e94bd4ef8a2c3b884cfa59ca342b2e",
        )

    def test_swap32_words_matches_report_example(self):
        iv = bytes.fromhex("00112233445566778899aabbccddeeff")
        expected = bytes.fromhex("3322110077665544bbaa9988ffeeddcc")
        self.assertEqual(swap32_words(iv), expected)

    def test_swap32_words_requires_sixteen_bytes(self):
        with self.assertRaises(ValueError):
            swap32_words(b"too short")

    def test_compute_s0_matches_report_example(self):
        key = bytes(16)
        iv = bytes.fromhex("00112233445566778899aabbccddeeff")
        expected = bytes.fromhex("1c74a257b03aa9b2e92434cf1f99f209")
        self.assertEqual(compute_s0(make_key_context(key), iv), expected)

    def test_zero_key_zero_iv_matches_report_example(self):
        self.assertEqual(
            compute_s0(make_key_context(bytes(16)), bytes(16)).hex(),
            "66e94bd4ef8a2c3b884cfa59ca342b2e",
        )

    def test_compute_s0_does_not_modify_inputs_or_context(self):
        key = bytearray(16)
        iv = bytearray(range(16))
        key_context = make_key_context(key)
        original_round_keys = list(key_context.round_keys)
        original_iv = bytes(iv)
        compute_s0(key_context, iv)
        self.assertEqual(bytes(iv), original_iv)
        self.assertEqual(key_context.round_keys, original_round_keys)

    def test_invalid_key_context_type_is_rejected(self):
        with self.assertRaises(TypeError):
            compute_s0(object(), bytes(16))


if __name__ == "__main__":
    unittest.main()
